import speech_recognition as sr
from cryptography.fernet import Fernet
import hashlib
import os
import numpy as np
from scipy.io import wavfile

# =========================
# 🔐 CHAVE
# =========================
def gerar_chave():
    if not os.path.exists("chave.key"):
        chave = Fernet.generate_key()
        with open("chave.key", "wb") as f:
            f.write(chave)

def carregar_chave():
    return open("chave.key", "rb").read()

# =========================
# 🔊 GRAVAR VOZ
# =========================
def gravar_audio(nome_arquivo="voz.wav", duracao=3):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎤 Gravando voz...")
        audio = recognizer.record(source, duration=duracao)

    with open(nome_arquivo, "wb") as f:
        f.write(audio.get_wav_data())

    print("✅ Voz registrada!")

# =========================
# 🔍 EXTRAIR “ASSINATURA” DA VOZ
# =========================
def extrair_caracteristicas(arquivo):
    taxa, dados = wavfile.read(arquivo)

    # Média e desvio padrão (simples, mas funcional)
    media = np.mean(dados)
    desvio = np.std(dados)

    return np.array([media, desvio])

# =========================
# 🔑 HASH
# =========================
def gerar_hash(texto):
    return hashlib.sha256(texto.encode()).hexdigest()

# =========================
# 👤 CADASTRO
# =========================
def cadastrar_usuario():
    senha = input("Defina uma senha: ")
    senha_hash = gerar_hash(senha)

    # Gravar voz
    gravar_audio("voz_cadastro.wav")
    caracteristicas = extrair_caracteristicas("voz_cadastro.wav")

    # Salvar dados
    np.save("voz.npy", caracteristicas)

    with open("usuario.sec", "w") as f:
        f.write(senha_hash)

    print("✅ Usuário cadastrado com biometria de voz!")

# =========================
# 🔐 AUTENTICAÇÃO
# =========================
def autenticar_usuario():
    if not os.path.exists("usuario.sec"):
        print("Nenhum usuário cadastrado.")
        return False

    # Verificar senha
    senha = input("Digite sua senha: ")
    senha_hash = gerar_hash(senha)

    with open("usuario.sec", "r") as f:
        senha_salva = f.read()

    if senha_hash != senha_salva:
        print("❌ Senha incorreta!")
        return False

    # Verificar voz
    gravar_audio("voz_login.wav")
    car_login = extrair_caracteristicas("voz_login.wav")
    car_salvo = np.load("voz.npy")

    # Comparação simples
    diferenca = np.linalg.norm(car_login - car_salvo)

    if diferenca < 500:  # tolerância
        print("✅ Voz reconhecida!")
        return True
    else:
        print("❌ Voz não reconhecida!")
        return False

# =========================
# 🔒 SISTEMA
# =========================
def sistema_corporativo():
    print("🔐 Acesso ao sistema seguro...")

    chave = carregar_chave()
    f = Fernet(chave)

    dado = "Dados confidenciais da empresa"
    criptografado = f.encrypt(dado.encode())

    print("📦 Criptografado:", criptografado)

    original = f.decrypt(criptografado).decode()
    print("📄 Original:", original)

# =========================
# 🚀 MAIN
# =========================
def main():
    gerar_chave()

    print("1 - Cadastrar usuário")
    print("2 - Login seguro")

    opcao = input("Escolha: ")

    if opcao == "1":
        cadastrar_usuario()
    elif opcao == "2":
        if autenticar_usuario():
            sistema_corporativo()

if __name__ == "__main__":
    main()